const { getCool, getVersion } = require('mycoollibrary');

console.log(`This is ${getCool()}!`);
console.log(`This is coming from version '${getVersion()}'!`);
