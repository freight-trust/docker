extern crate generic_rust_library;

use smart_rust_library::get_the_answer;

fn main() {
    println!("Hello, world!");
    println!("The answer is {}!", get_the_answer());
}
