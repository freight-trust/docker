const { getCool, getVersion } = require('./generic');

module.exports = {
  getGeneric,
  getVersion
}
