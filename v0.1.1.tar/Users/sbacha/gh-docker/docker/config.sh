#!/bin/sh

cat .env > config.json
